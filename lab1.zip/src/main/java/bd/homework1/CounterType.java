package bd.homework1;

public enum CounterType {
    MALFORMED
}
